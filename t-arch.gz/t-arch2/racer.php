<iframe src = "racer" style = "width:995px;height:520px;" frameborder = "0" id = "gameracie"></iframe>
<script>
function check() {
  if (document.getElementById("gameracie").parentNode.parentNode.style.display == "none") {
    document.getElementById("gameracie").src = "";
    console.log("true")
  }
  else {
    console.log("false")
  }
}

setTimeout(check, 1000);
</script>