<div class="loader" id="load">
  <img src = "img/TovinOS.png" width = "300px"/>
  <div class = "loadtoolong">Seems like TovinOS is taking long to load. Try using another computer/browser</div>
</div>