<div>
<h1>&nbsp;&nbsp;&nbsp;&nbsp;About TovinOS</h1>
<h3>&nbsp;&nbsp;&nbsp;&nbsp;Version: Alpha, revision <?php include("version.txt")?></h3>
<h3>&nbsp;&nbsp;&nbsp;&nbsp;Codename: Dash</h3>
<br>
</div>