<div id="contextMenu" class="context-menu" style="display: none">
        <ul class="menu">
            <li class="file"><a href="#"><i class="fa fa-file" aria-hidden="true"></i> New file</a></li>
            <li class="folder"><a href="#"><i class="fa fa-folder" aria-hidden="true"></i>New folder</a></li>
            <hr style = "width: 200px;">
            <li class="wppr"><a href="#" onclick = "show()"><i class="fa fa-image" aria-hidden="true"></i>Change background</a></li>
            <li class="settings"><a href="#" onclick = "show()"><i class="fa fa-image" aria-hidden="true"></i>Desktop settings</a></li>
            <hr style = "width: 200px;">
            <li class="terminal"><a href="#"><i class="fa fa-terminal" aria-hidden="true"></i>Terminal</a></li>
        </ul>
    </div>