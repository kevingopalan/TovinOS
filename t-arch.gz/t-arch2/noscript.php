<noscript>
      <style>
        #noscript{
          opacity:1;
        }
        
        .cover{
          background:url('https://images.unsplash.com/photo-1579546929662-711aa81148cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXw4MDIwMjAzOHx8ZW58MHx8fHw%3D&w=1000&q=80')no-repeat center fixed;
          background-size:cover;
        }
      </style>
      <div class = "cover" id = "noscript" style = "z-index:1001;">
        <div class = "mnu"><h1 style = "transform:rotate(90deg)">:-(</h1><h1>Your JavaScript is off!</h1><p>Please turn on your JavaScript. There is no alternate way right now.</div>
      </div>
    </noscript>