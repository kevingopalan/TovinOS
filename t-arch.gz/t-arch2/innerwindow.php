<div class="popup-header">
    <span class = "hbtn" onmousedown = "maximize(this)">□</span><span class = "hbtn">-</span><span onmousedown = "hide(this)" class = "hbtn close">×</span>
  </div>
  <div class="popup-fullheader">
    <span class = "hbtn" onmousedown = "maximize(this)">□</span><span class = "hbtn">-</span><span onmousedown = "hide(this)" class = "hbtn close">×</span>
  </div>
    <div id = "reduceload">
   </div>