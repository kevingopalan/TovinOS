<div class = "setup">
  <h1>Welcome</h1>
  <p>Press the button to get started</p>
  <button onclick = "this.parentNode.style.display = 'none'; localStorage.setupFinished = 'yes'">Continue</button>
</div>