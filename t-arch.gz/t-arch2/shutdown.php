<div class="cover" id="cover" onclick="hidemenu()">
        <div class="mnu" id="ll">
            <a onclick="sdown()"><img src = "img/wow64/48x48/apps/system-shutdown.svg" height="48px" width="48px" /></a>
            <img onclick = "logouto()" src="img/wow64/48x48/apps/system-log-out.svg" height="48px" width="48px" />
            <img src="img/wow64/24x24/status/dialog-information.svg" height="48px" width="48px" onclick="showWindow(2, 'about.php')" />
        </div>
    </div>