<form onsubmit = "return false">
<input type = "text" id = "wallurl"/>
<input type = "submit" onclick = "bg()">
</form>
<br>
<label><input type="checkbox" id="myCheck" onclick="darklight()"/> Dark Mode</label>
<span id = "val"></span>